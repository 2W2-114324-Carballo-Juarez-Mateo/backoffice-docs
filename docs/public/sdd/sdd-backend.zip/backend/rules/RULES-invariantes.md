# RULES — Invariantes de negocio (NUNCA violar)

Estas reglas vienen del PRD y **no se negocian en código**. Si un requerimiento parece contradecirlas, preguntá antes de cambiar nada.

1. **Último ADMIN:** el sistema nunca puede quedar con cero ADMIN activos. Bloqueo incondicional; validar con **transacción + revalidación** (no solo pre-validación).
2. **Auto-eliminación:** un ADMIN no puede eliminarse a sí mismo (RF-ROL-02).
3. **Baja de ADMIN reforzada:** requiere contraseña + 2FA + confirmación escrita (RF-ROL-06).
4. **ADMIN sin sub-niveles:** todos los ADMIN tienen los mismos permisos (RF-ROL-01).
5. **Sin hard delete:** toda la producción académica usa **baja lógica** (`deleted_at`/`deleted_by`/`deletion_reason`). La única excepción (chat social) no es del BackOffice.
6. **Configuración hacia adelante:** un cambio de parámetro global **nunca** recalcula XP/monedas históricos (RF-CFG-06).
7. **Ámbito de configuración:** PROFESOR no puede modificar parámetros globales (PAR-01..18), solo ADMIN (RF-CFG-05).
8. **Activación de curso sin override:** `draft → activo` exige padrón cargado + calibración de IA aprobada. No existe override (RF-CUR-08b, RF-IA-36).
9. **Archivado bloqueado con scores pendientes:** no se archiva un curso con scores de IA pendientes de cálculo diferido (RF-IA-34).
10. **Auditoría inmutable:** los eventos de auditoría no se modifican desde las APIs administrativas (RF-AUD-04).
11. **Aislamiento por tenant:** toda consulta sobre datos de curso está limitada por `tenant_id`; el `tenant_id` del cliente se valida contra la membresía real.
12. **No acceder a la DB de otro servicio:** Database per Service; relaciones solo por API/eventos.

> Si necesitás "bajar" una de estas reglas, es decisión del Product Owner, no del código.
# SKILL — Agregar un endpoint (de punta a punta)

Ejemplo: `POST /api/courses/{id}/activate` en **course-service**.

## 1. Api — Controller + DTO

- `api/controllers/CourseController.java`: método `POST /api/courses/{id}/activate`.
- DTO de request/response en `api/dto` (validaciones con Jakarta Validation).
- Anotá la autorización mínima (`@PreAuthorize("hasRole('ADMIN') or hasRole('PROFESOR')")`); el **alcance** se valida en aplicación.

## 2. Application — Command

- `application/commands/ActivateCourseCommand.java` + `ActivateCourseCommandHandler.java`.
- El handler orquesta: valida que exista el curso → valida la **regla de negocio** (padrón + calibración IA) → persiste el cambio → registra el **Outbox event** → devuelve resultado.

## 3. Domain — regla

- Si la activación tiene guardas complejas, usá el patrón **State** o **Specification** (`domain/state` o `domain/specifications`). No pongas la lógica en el controller.

## 4. Infrastructure — persistencia + evento

- Repositorio JPA para `Course`.
- Si el cambio debe notificar (ej. `CourseActivated`), escribí `OutboxMessage` en la misma transacción (ver `SKILL-evento.md`).

## 5. Documentación y tests

- Endpoint queda documentado por springdoc/OpenAPI (anotaciones en el controller).
- Test unitario del handler + test de integración (MockMvc + Testcontainers).
- Actualizá `docs/05-endpoints.md` (matriz endpoint → rol → alcance).

> **Recordá:** autorización siempre en el servicio, alcance por curso validado, errores con formato uniforme, y sync de `sdd/`.
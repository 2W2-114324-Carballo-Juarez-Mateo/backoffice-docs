# Backend — Índice de redirección

> **LEELO PRIMERO.** Este mapa te dice qué archivo leer según la tarea. No leas todo: buscá tu tarea y entrá al/los archivo(s) indicado(s).

## Contexto rápido

- **Stack:** Java 21 · Spring Boot 3 · Maven (multi-módulo) · PostgreSQL · Apache Kafka · Eureka · Spring Cloud Gateway.
- **Arquitectura:** microservicios por dominio (5 servicios), Clean Architecture por capas, Database per Service, Outbox + idempotencia.
- **Fuentes detalladas (raíz del proyecto):** `backoffice_backend_requerimientos_arquitectura.md` · `BackOffice Resumen Visual.md`.

## Redirección por tarea

| Tarea | Leer |
|---|---|
| Entender qué es el BackOffice (contexto general) | `docs/01-overview.md` |
| Ver diagrama y principios de la arquitectura | `docs/02-arquitectura.md` |
| Conocer los 5 microservicios y sus bases | `docs/03-microservicios.md` |
| Crear/alterar entidades o tablas | `docs/04-modelo-datos.md` |
| Agregar o modificar un endpoint | `docs/05-endpoints.md` + `skills/SKILL-endpoint.md` + `rules/RULES-stack.md` |
| Aplicar un patrón de diseño | `docs/06-patrones.md` + `skills/SKILL-caso-uso.md` |
| Trabajar autenticación/autorización/roles | `docs/07-seguridad.md` + `rules/RULES-seguridad.md` |
| Publicar o consumir eventos | `docs/08-eventos-kafka.md` + `skills/SKILL-evento.md` + `rules/RULES-eventos.md` |
| Compilar, testear, docker | `skills/SKILL-build-test.md` + `skills/SKILL-despliegue.md` |
| Reglas que NUNCA se deben violar | `rules/RULES-invariantes.md` (leer siempre) |

## Orden recomendado para un agente que arranca

1. `docs/01-overview.md` (contexto).
2. `rules/RULES-invariantes.md` (no romper nada).
3. `rules/RULES-stack.md` (convenciones de código).
4. Recién ahí, el `docs/` + `skills/` específico de tu tarea.

## Convenciones de archivo

- Los `docs/*` describen **qué** y **por qué**. Los `rules/*` dicen **qué está prohibido/obligado**. Los `skills/*` dicen **cómo** se hace.
- Los `rules/*` tienen prioridad sobre cualquier preferencia de estilo del agente. Si un `docs/` y un `rules/` se contradicen, el `rules/` manda y hay que reportar la contradicción.
- Mantené este índice actualizado si agregás/renombrás/quitas archivos.
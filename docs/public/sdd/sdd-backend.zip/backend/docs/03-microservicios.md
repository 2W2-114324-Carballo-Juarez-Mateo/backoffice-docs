# 03 — Microservicios (los 5)

Cada servicio tiene **base propia** y capas Clean Architecture. No hay FKs entre bases; las relaciones se modelan con IDs.

## Identity & User Service

- Login, credenciales, **2FA (TOTP)**, sesiones, roles, estados de cuenta.
- Reglas de ADMIN: último ADMIN, auto-eliminación, **break-glass** (server-only), baja reforzada.
- **Base:** `identity_db`
- **No debe:** gestionar cursos ni modificar parámetros económicos.

## Course & Content Service

- CRUD de cursos, estados (`draft → activo → archivado`), propietario.
- **Padrón** (alta, carga masiva CSV, modificación, baja lógica).
- Desafíos y configuración propia del curso.
- Validaciones de transición: activar exige padrón + calibración IA; archivar exige cierre académico + cero scores IA.
- **Base:** `course_db`

## Configuration Service

- Parámetros globales de economía (**PAR-01..PAR-18**) y operativos.
- Versionado y aplicación **hacia adelante** (RF-CFG-06).
- Permisos ADMIN exclusivos.
- **Base:** `configuration_db`

## Audit Service

- Registro de operaciones administrativas sensibles (transversal, **inmutable**).
- Recibe eventos de auditoría; consulta restringida.
- **Base:** `audit_db`

## Reporting Service

- Consultas y agregados administrativos (read models).
- Consume eventos de otros servicios (replay de Kafka).
- **No es dueño** de la información operacional.
- **Base:** `reporting_db`

## Tabla de bases

| Servicio | Base |
|---|---|
| Identity & User | identity_db |
| Course & Content | course_db |
| Configuration | configuration_db |
| Audit | audit_db |
| Reporting | reporting_db |

> Detalle de responsabilidades y "no debe": `backoffice_backend_requerimientos_arquitectura.md` (§8).
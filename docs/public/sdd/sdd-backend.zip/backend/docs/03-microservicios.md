# 03 — Microservicios (los 4)

Cada servicio tiene **base propia** y capas Clean Architecture. No hay FKs entre bases; las relaciones se modelan con IDs.

## Identity & Access Service (lado ADMIN)

- Login, credenciales, **2FA (TOTP)**, sesiones (JWT en cookie httpOnly).
- Roles y permisos (RBAC).
- Gestión de ADMIN: alta, baja, reglas de ADMIN, **break-glass** (server-only), último ADMIN.
- **Base:** `identity_db`
- **No debe:** onboarding de usuarios (equipo Usuarios), modificar configuración/proveedores.

## Administration & Configuration Service

- Parámetros globales de economía (**PAR-01..PAR-18**) y operativos, versionados, hacia adelante.
- **Gestión de proveedores de LLM** (RF-IA-35): alta, sustitución, baja, auditada.
- **Asignación modelo ↔ función** (RF-IA-23/24).
- **Configuración del evaluador** (RF-IA-25/28): modelo único activo, cambio con calibración.
- **Golden set base y calibración a nivel plataforma** (RF-IA-30/31).
- **Detección de deriva** (RF-IA-32).
- **Base:** `administration_db`
- **No debe:** llamar a los LLM (es el AI Service de otro equipo); gestionar cursos/desafíos/usuarios.

## Reporting & Analytics Service

- **Reportes docentes** por curso (PROFESOR) y consolidado de plataforma (ADMIN).
- **Panel de métricas de curso**: satisfacción (encuestas agregadas/anónimas), engagement, aprobación/abandono.
- **Exportación de datos** (resúmenes, reportes CSV/PDF).
- Consume eventos de otros equipos (Cursos, Gamificación, Ranking, Encuestas) → read models.
- **Base:** `reporting_db` (reconstruible por replay de Kafka).

## Audit Service

- Registro de operaciones administrativas sensibles (transversal, **inmutable**).
- Recibe eventos de auditoría; consulta restringida.
- **Base:** `audit_db`

## Tabla de bases

| Servicio | Base |
|---|---|
| Identity & Access | identity_db |
| Administration & Configuration | administration_db |
| Reporting & Analytics | reporting_db |
| Audit | audit_db |

> Detalle de responsabilidades y "no debe": `backoffice_backend_requerimientos_arquitectura.md` (§8).
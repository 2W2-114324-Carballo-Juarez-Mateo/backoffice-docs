# 05 — Endpoints y autorización

Convención REST, APIs versionadas (`/api/v1/...`), documentadas con springdoc/OpenAPI. La autorización se valida **siempre** en el microservicio (el Gateway no es frontera suficiente).

## Endpoints por dominio

**Identity & Access (lado ADMIN)**

```http
POST /api/auth/login
POST /api/auth/2fa/verify
POST /api/auth/logout
GET    /api/admin/accounts
GET    /api/admin/accounts/{id}
POST   /api/admin/accounts
DELETE /api/admin/accounts/{id}
```

**Administration & Configuration**

```http
GET  /api/administration/parameters
GET  /api/administration/parameters/{key}
PUT  /api/administration/parameters/{key}
GET    /api/administration/model-providers
POST   /api/administration/model-providers
PUT    /api/administration/model-providers/{id}
DELETE /api/administration/model-providers/{id}
GET  /api/administration/model-functions
PUT  /api/administration/model-functions/{function}
POST /api/administration/evaluator/activate
GET  /api/administration/evaluator/calibration
```

**Reporting & Analytics (reportes, métricas, export)**

```http
GET /api/reports/platform
GET /api/reports/courses/{courseId}
GET /api/reports/courses/{courseId}/metrics
GET /api/reports/courses/{courseId}/teacher
GET /api/export/courses/{courseId}      ← CSV/PDF
GET /api/export/platform
```

**Audit**

```http
GET /api/audit
GET /api/audit/{id}
```

## Matriz endpoint → rol → alcance (resumen)

| Endpoint | Roles | Alcance |
|---|---|---|
| `/api/auth/*` | todos / público | — |
| `/api/admin/accounts*` | ADMIN | global (gestión de ADMIN) |
| `/api/administration/parameters/{key}` PUT | ADMIN | exclusivo ADMIN |
| `/api/administration/model-providers*` | ADMIN | exclusivo ADMIN (RF-IA-35) |
| `/api/administration/model-functions*` | ADMIN | exclusivo ADMIN |
| `/api/administration/evaluator/*` | ADMIN | exclusivo ADMIN |
| `/api/audit` | ADMIN | global |
| `/api/reports/platform` | ADMIN | global |
| `/api/reports/courses/{courseId}*` | ADMIN, PROFESOR | PROFESOR: solo su curso (alcance cross-team) |
| `/api/export/*` | ADMIN / PROFESOR | según recurso |

## Manejo de errores

Formato uniforme:

```json
{ "code": "PARAMETER_FORBIDDEN_FOR_ROLE", "message": "...", "correlationId": "..." }
```

| Código HTTP | Uso |
|---|---:|
| 200/201/204 | Éxito |
| 400 / 401 / 403 / 404 | Datos / auth / permisos / no existe |
| 409 | Regla de negocio |
| **429** | **Rate limiting (con `Retry-After`)** |
| 422 | Validación semántica |
| 500 / 503 | Error / dependencia no disponible |

Códigos de negocio destacados: `LAST_ADMIN_PROTECTION`, `PARAMETER_FORBIDDEN_FOR_ROLE`, `MODEL_PROVIDER_FORBIDDEN_FOR_ROLE`, `MODEL_EVALUATOR_CALIBRATION_REQUIRED`, `COURSE_NOT_ACCESSIBLE` (cross-team), `REPORT_ANONYMITY_VIOLATION`, `RATE_LIMIT_EXCEEDED`.

> Fuente: `backoffice_backend_requerimientos_arquitectura.md` (§28-§29).
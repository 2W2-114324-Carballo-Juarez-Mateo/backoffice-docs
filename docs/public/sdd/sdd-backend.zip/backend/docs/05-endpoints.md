# 05 — Endpoints y autorización

Convención REST, APIs versionadas (`/api/v1/...`), documentadas con springdoc/OpenAPI. La autorización se valida **siempre** en el microservicio (el Gateway no es frontera suficiente).

## Matriz endpoint → rol → alcance

| Endpoint | Método | Roles | Alcance |
|---|---|---|---|
| `/api/auth/login` | POST | público | — |
| `/api/auth/2fa/verify` | POST | todos | — |
| `/api/users` | GET | ADMIN | global |
| `/api/users/admin` | POST | ADMIN | contraseña + 2FA del solicitante |
| `/api/users/admin/{id}` | DELETE | ADMIN | no auto-eliminación + 2FA + confirmación + último ADMIN |
| `/api/courses` | GET | ADMIN, PROFESOR | ADMIN: todos; PROFESOR: solo los suyos |
| `/api/courses` | POST | ADMIN, PROFESOR | PROFESOR crea propio |
| `/api/courses/{id}` | GET/PUT | ADMIN, PROFESOR | PROFESOR: solo si es dueño |
| `/api/courses/{id}/activate` | POST | ADMIN, PROFESOR | padrón + calibración IA (sin override) |
| `/api/courses/{id}/archive` | POST | ADMIN, PROFESOR | cierre académico + cero scores IA |
| `/api/courses/{id}/roster` | GET/POST | PROFESOR, ADMIN | PROFESOR: solo su curso |
| `/api/courses/{id}/roster/import` | POST | PROFESOR, ADMIN | carga masiva CSV |
| `/api/configuration/global` | GET | ADMIN, PROFESOR | PROFESOR: solo lectura |
| `/api/configuration/global/{key}` | PUT | ADMIN | exclusivo ADMIN |
| `/api/audit` | GET | ADMIN | global |
| `/api/reports/platform` | GET | ADMIN | global |
| `/api/reports/courses/{courseId}` | GET | ADMIN, PROFESOR | PROFESOR: solo su curso |

## Manejo de errores

Formato uniforme:

```json
{ "code": "COURSE_NOT_ACCESSIBLE", "message": "El usuario no tiene acceso al curso.", "correlationId": "..." }
```

| Código HTTP | Uso |
|---|---:|
| 200/201/204 | Éxito |
| 400 / 401 / 403 / 404 | Datos / auth / permisos / no existe |
| 409 | Regla de negocio |
| **429** | **Rate limiting (con `Retry-After`)** |
| 422 | Validación semántica |
| 500 / 503 | Error / dependencia no disponible |

Códigos de negocio destacados: `LAST_ADMIN_PROTECTION`, `COURSE_NOT_ACCESSIBLE`, `COURSE_NOT_ACTIVATABLE`, `RATE_LIMIT_EXCEEDED`, `DUPLICATE_REQUEST`, `PARAMETER_FORBIDDEN_FOR_ROLE`, `ROSTER_IMPORT_FILE_INVALID`.

## Import de padrón (CSV)

- Encabezado obligatorio: `legajo,email`.
- Errores por fila **sin interrumpir** el resto; respuesta `{added, updated, duplicates, errors}`.
- No reemplaza el padrón existente (acumula).

> Fuente: `backoffice_backend_requerimientos_arquitectura.md` (§28-§29).
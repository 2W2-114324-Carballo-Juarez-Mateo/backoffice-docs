# 02 — Arquitectura del Backend

## Estilo

**Microservicios orientados a dominios** (bounded contexts), no un microservicio por entidad. Cada servicio con Clean Architecture (`api → application → domain ← infrastructure`) y su propia base (**Database per Service**). El BackOffice cubre **4 servicios**.

## Diagrama

```text
Frontend (por definir) → API Gateway (Spring Cloud Gateway)
                              ├── Identity & Access Service → identity_db
                              ├── Administration & Configuration Service → administration_db
                              ├── Reporting & Analytics Service → reporting_db
                              └── Audit Service → audit_db

Infra: Eureka (discovery) · Config Server · Kafka (eventos) · PostgreSQL por servicio
```

## Principios

- **Autorización distribuida:** el Gateway valida el JWT, pero cada microservicio revalida identidad, rol, permisos y **alcance del recurso**.
- **Consumo de dominios ajenos:** cursos, desafíos, usuarios, gamificación, ranking, encuestas e IA como producto son de otros equipos; el BackOffice los **consume** vía eventos (reportes, métricas).
- **Comunicación:** REST (síncrono, respuesta inmediata) + **Kafka** (asíncrono, eventos de dominio) con **Outbox** e **idempotencia**.
- **Correlation ID** propagado en todo el recorrido.
- **Rate limiting** en Gateway (429 con `Retry-After`) + Idempotency Keys en operaciones críticas.

## Service Discovery (Eureka)

Los microservicios se registran al iniciar; el Gateway consulta a Eureka la ubicación de la instancia activa antes de enrutar (sin direcciones fijas).

## Roles de los componentes

| Componente | Rol |
|---|---|
| API Gateway | Entrada única: routing, JWT, rate limiting, correlation ID, CORS, errores uniformes. Sin lógica de negocio |
| Eureka | Registro + health + ubicación de instancias |
| Config Server | Configuración no sensible, perfiles por ambiente |
| Kafka | Eventos de dominio, read models, auditoría |

> Fuente completa: `backoffice_backend_requerimientos_arquitectura.md` (§6-§11).
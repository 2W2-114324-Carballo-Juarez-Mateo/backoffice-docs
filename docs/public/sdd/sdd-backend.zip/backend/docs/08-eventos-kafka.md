# 08 — Eventos con Apache Kafka

Broker elegido: **Apache Kafka** (ADR-003). RabbitMQ queda como alternativa. Mismos patrones de confiabilidad: **Outbox + at-least-once + idempotencia**.

## Envelope común

```json
{
  "eventId": "uuid",
  "eventType": "CourseArchived",
  "occurredAt": "2026-08-28T12:00:00Z",
  "correlationId": "uuid",
  "actorId": "uuid",
  "source": "course-service",
  "payload": {}
}
```

## Topics y particionado

| Topic | Eventos | Partición |
|---|---|---|
| `identity.events` | UserCreated, UserRoleChanged, AdminDeleted, AdminRecoveryExecuted | por `actorId` |
| `course.events` | CourseCreated/Activated/Archived, RosterUpdated | **por `courseId`** |
| `configuration.events` | GlobalConfigurationChanged | por `key` |
| `audit.events` | eventos de auditoría | por `actorId` |
| `retention.events` | RetentionDecisionCreated, DataAnonymized | por `courseId` |

Cada servicio consume con su **consumer group** y offset propio. Kafka permite **replay** (reconstruir read models de Reporting y auditoría).

## Outbox

Persistir el cambio y el `OutboxMessage` en la **misma transacción**; un publisher envía luego al topic. Evita "commit sin evento".

## Idempotencia

Cada evento lleva `event_id`; el consumidor registra los procesados en `ProcessedEvent(event_id, consumer)` y ignora duplicados.

## Flujo de ejemplo

```text
Course Service
  │ CourseArchived
  ▼
Kafka (course.events)
  ├──► Audit Service      (consumer group: audit)
  └──► Reporting Service  (consumer group: reporting)
```

> Fuente: `backoffice_backend_requerimientos_arquitectura.md` (§11-§14, §12 topics).
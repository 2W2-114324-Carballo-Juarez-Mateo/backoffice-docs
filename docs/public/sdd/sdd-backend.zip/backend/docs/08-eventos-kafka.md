# 08 — Eventos con Apache Kafka

Broker elegido: **Apache Kafka** (ADR-003). RabbitMQ queda como alternativa. Mismos patrones de confiabilidad: **Outbox + at-least-once + idempotencia**.

## Envelope común

```json
{
  "eventId": "uuid",
  "eventType": "ModelProviderChanged",
  "occurredAt": "2026-08-28T12:00:00Z",
  "correlationId": "uuid",
  "actorId": "uuid",
  "source": "administration-service",
  "payload": {}
}
```

## Topics y particionado

| Topic | Eventos | Rol BackOffice | Partición |
|---|---|---|---|
| `identity.events` | AdminCreated, AdminDeleted, AdminRecoveryExecuted, RoleChanged | Publica | por `actorId` |
| `administration.events` | GlobalConfigurationChanged, ModelProviderChanged, ModelFunctionChanged | Publica | por `key` |
| `audit.events` | eventos de auditoría | Publica | por `actorId` |
| `retention.events` | RetentionDecisionCreated, DataAnonymized | Publica | por `resourceId` |
| `course.events` | CourseCreated/Activated/Archived, RosterUpdated | **Consume** | por `courseId` |
| `gamification.events` / `ranking.events` / `survey.events` | eventos de otros equipos | **Consume** | por `courseId` |

Cada servicio consume con su **consumer group** y offset propio. Kafka permite **replay** (reconstruir read models de Reporting y auditoría).

## Outbox

Persistir el cambio y el `OutboxMessage` en la **misma transacción**; un publisher envía luego al topic. Evita "commit sin evento".

## Idempotencia

Cada evento lleva `event_id`; el consumidor registra los procesados en `ProcessedEvent(event_id, consumer)` y ignora duplicados.

## Flujo de ejemplo

```text
Administration & Configuration Service
  │ GlobalConfigurationChanged / ModelProviderChanged
  ▼
Kafka (administration.events)
  ├──► Audit Service      (consumer group: audit)
  └──► AI / Gamification  (cross-team, consumen la configuración)
```

```text
Cursos Service (equipo Cursos)
  │ CourseArchived / RosterUpdated
  ▼
Kafka (course.events)
  ▼
Reporting & Analytics Service (consumer group: reporting)
```

> Fuente: `backoffice_backend_requerimientos_arquitectura.md` (§11-§14, §12 topics).
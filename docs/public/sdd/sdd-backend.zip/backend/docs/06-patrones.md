# 06 — Patrones de diseño aplicados

Mapa de patrones con el lugar concreto. Paquetes bajo `com.backoffice.<servicio>`.

## Domain

- **State** → `course.domain.state` (`CourseState` + `DraftState`, `ActiveState`, `ArchivedState`). Ciclo de vida de Course con guardas en el dominio (RF-CUR-04/06/07).
- **Specification** → `course.domain.specifications` (`CanActivateCourseSpec`, `CanArchiveCourseSpec`), `identity.domain.specifications` (`AtLeastOneActiveAdminSpec`). Reglas compuestas y testeables (RF-CUR-08b, RF-ROL-05).
- **Strategy** → `course.domain.rewards` (`RewardStrategy` + por dificultad, PAR-01/03), `configuration.domain.retention` (`RetentionDecisionStrategy`: extender/anonimizar). Políticas intercambiables (RF-DES-07, RF-RET-03).
- **Null Object** → `course.infrastructure.external` (`CalibrationClient` + `NoOpCalibrationClient`). Fallback ante IA no disponible (RF-IA-27).
- **Prototype** → `course.domain` (`CourseTemplate.clone()`). Curso desde template (RF-CUR-02).

## Application

- **Command** → `*.application.commands` (`CreateCourseCommand`, `ActivateCourseCommand`, `ArchiveCourseCommand` + handlers). Casos de uso aislados del HTTP.
- **Chain of Responsibility** → `identity.application.validation` (`AdminDeletionValidator`: auto-eliminación → 2FA → confirmación → último ADMIN). (RF-ROL-06)
- **Decorator** → `audit.application` (`AuditableCommandDecorator`). Auditoría transversal sin ensuciar el caso de uso (RF-AUD-01/03).
- **Template Method** → `course.application.roster` (`RosterImportTemplate`). Import de padrón con pasos comunes (RF-USR-05d).

## Infrastructure

- **Adapter** → `*.infrastructure.external` (`IdentityClient`, `CalibrationClient`, `RankingClient`). Aísla red/DTOs.
- **Repository** → `*.infrastructure.persistence` (Spring Data JPA).
- **Observer + Outbox** → `*.domain.events` + `*.messaging.outbox`. Entrega de eventos en la misma transacción.
- **Unit of Work** → servicio `@Transactional` que persiste entidad + `OutboxMessage` en el mismo commit.
- **Idempotency Key** → `*.api.filter` / `*.application.commands`. Operaciones críticas (PUT config, baja ADMIN) responden el resultado original ante duplicados.

## Tabla resumen

| Patrón | Paquete | RF |
|---|---|---|
| State | `course.domain.state` | RF-CUR-04/06/07 |
| Specification | `*.domain.specifications` | RF-CUR-08b · RF-ROL-05 |
| Strategy | `course.domain.rewards` · `configuration.domain.retention` | RF-DES-07 · RF-RET-03 |
| Null Object | `course.infrastructure.external` | RF-IA-27 |
| Prototype | `course.domain` | RF-CUR-02 |
| Command | `*.application.commands` | capas |
| Chain of Responsibility | `identity.application.validation` | RF-ROL-06 |
| Decorator | `audit.application` | RF-AUD-01/03 |
| Template Method | `course.application.roster` | RF-USR-05d |
| Adapter | `*.infrastructure.external` | cross-team |
| Observer + Outbox | `*.domain.events` · `*.messaging.outbox` | eventos |
| Unit of Work | `@Transactional` | outbox |
| Idempotency Key | `*.api.filter` | 429/duplicados |

> Fuente: `backoffice_backend_requerimientos_arquitectura.md` (§25bis).
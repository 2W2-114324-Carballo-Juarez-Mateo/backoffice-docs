# 09 — Despliegue y estructura del repo

## Monorepo Maven multi-módulo

```text
backoffice-backend/
├── pom.xml                     ← POM padre
├── gateway/                    ← Spring Cloud Gateway
├── discovery-server/           ← Eureka
├── config-server/              ← Spring Cloud Config Server
├── services/
│   ├── identity-service/       ← com/backoffice/identity/{api,application,domain,infrastructure}
│   ├── course-service/         ← com/backoffice/course/...
│   ├── configuration-service/  ← com/backoffice/configuration/...
│   ├── audit-service/          ← com/backoffice/audit/...
│   └── reporting-service/      ← com/backoffice/reporting/...
├── building-blocks/
│   ├── contracts/              ← DTOs y contratos de eventos compartidos
│   ├── shared-kernel/
│   ├── observability/
│   └── security/
├── tests/
├── deploy/docker/
└── docker-compose.yml
```

## Estructura interna de un microservicio

```text
course-service/src/main/java/com/backoffice/course/
├── CourseApplication.java          ← @SpringBootApplication
├── api/        ← controllers, dto, exception (@RestControllerAdvice), config
├── application/ ← commands, queries, dto, validators, ports
├── domain/     ← model, events, exceptions, services
└── infrastructure/ ← persistence (JPA), messaging (outbox + kafka), external
```

## Docker Compose (local)

```text
discovery-server · config-server · gateway
identity · course · configuration · audit · reporting
PostgreSQL (una base por servicio) · Kafka (KRaft, sin ZooKeeper)
```

## Configuración

- `application.yml` con valores no sensibles; secretos por variables de entorno (`DATABASE_PASSWORD`, `JWT_SECRET`, `KAFKA_BOOTSTRAP_SERVERS`, `BREAK_GLASS_SECRET`).
- Migraciones con **Flyway** (`db/migration/`).

## Observabilidad (MVP)

- Health checks (`/health/live`, `/health/ready`), logs estructurados, correlation ID.
- Prometheus/Grafana/OpenTelemetry: **opcional según tiempo** (instrumentación preparada vía actuator).

> Fuente: `backoffice_backend_requerimientos_arquitectura.md` (§23-§27, §32).
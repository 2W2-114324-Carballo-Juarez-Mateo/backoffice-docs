# 01 — Overview del BackOffice

## Qué es

El **BackOffice** es el backend administrativo de la Plataforma Gamificada: lo usan **ADMIN** y **PROFESOR** para operar la plataforma (configuración, usuarios/roles, cursos, padrón, auditoría, reporting) con trazabilidad y seguridad.

## Roles

| Rol | Alcance |
|---|---|
| ADMIN | Todo, config global, auditoría, gestión de ADMIN |
| PROFESOR | Crea/administra sus cursos, padrón, desafíos, config de curso |
| ALUMNO | Participa y compite (fuera del BackOffice) |

## Stack

| Capa | Tecnología |
|---|---|
| Lenguaje | Java 21 (LTS) |
| Framework | Spring Boot 3 |
| Build | Maven (multi-módulo) |
| Gateway | Spring Cloud Gateway |
| Discovery | Eureka |
| Config | Spring Cloud Config Server |
| Mensajería | Apache Kafka + Outbox (RabbitMQ = alternativa) |
| Persistencia | JPA/Hibernate · PostgreSQL (recomendada) |
| API docs | springdoc / OpenAPI 3 |
| Seguridad | Spring Security + JWT + 2FA (TOTP) |
| Pruebas | JUnit 5 · Mockito · Testcontainers · Spring Cloud Contract (opcional) |

## Reglas de negocio más importantes

- Nunca queda la plataforma **sin ADMIN activo** (incondicional).
- Un ADMIN **no puede auto-eliminarse**; baja reforzada (contraseña + 2FA + confirmación).
- **No existe hard delete** (baja lógica) en producción académica.
- Los cambios de configuración **rigen solo hacia adelante**.
- Un curso **no se activa** sin padrón cargado + calibración de IA aprobada (sin override).
- La auditoría es **inmutable**.

> Detalle: `rules/RULES-invariantes.md` · Fuente completa: `backoffice_backend_requerimientos_arquitectura.md`.
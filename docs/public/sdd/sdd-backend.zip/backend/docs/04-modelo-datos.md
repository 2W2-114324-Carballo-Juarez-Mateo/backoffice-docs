# 04 — Modelo de datos

Modelo detallado por servicio (campos/tipos JPA). Relaciones entre dominios = IDs (sin FKs entre bases).

## identity_db — User

| Campo | Tipo | Notas |
|---|---|---|
| id | UUID | PK |
| first_name / last_name | varchar(100) | |
| legajo | varchar(20) | validado contra padrón (RF-USR-05b) |
| email | varchar(255) | único, institucional/whitelist |
| password_hash | varchar(255) | bcrypt |
| role | enum | ADMIN \| PROFESOR \| ALUMNO |
| status | enum | ACTIVE \| PENDING_VALIDATION \| DISABLED |
| validated_by | enum | ROSTER \| EXCEPTION \| NONE (RF-USR-05h) |
| two_factor_enabled | boolean | |
| created_at / deleted_at | timestamp | baja lógica |

## course_db

**Course**

| Campo | Tipo | Notas |
|---|---|---|
| id | UUID | PK |
| name | varchar(150) | |
| description | text | |
| owner_user_id | UUID | FK lógica → Identity |
| status | enum | DRAFT \| ACTIVE \| ARCHIVED |
| invitation_code | varchar(20) | único; regenerable |
| created_at / archived_at / deleted_at | timestamp | |

**CourseRoster** (padrón, tenant-scoped) — índice único `(course_id, legajo)`

| Campo | Tipo | Notas |
|---|---|---|
| id | UUID | PK |
| course_id | UUID | tenant |
| legajo | varchar(20) | |
| email | varchar(255) | institucional |
| status | enum | ACTIVE \| REMOVED |
| imported_at / deleted_at | timestamp | |

**Challenge**

| Campo | Tipo | Notas |
|---|---|---|
| id | UUID | PK |
| course_id | UUID | tenant |
| title | varchar(200) | |
| difficulty | enum | BASICO \| MEDIO \| AVANZADO |
| required | boolean | RF-DES-06 |
| retry_count | int | 0–3 (RF-DES-07) |
| status | enum | DRAFT \| PUBLISHED \| RETIRED |
| created_by | UUID | FK lógica → Identity |

## configuration_db — GlobalParameter

| Campo | Tipo | Notas |
|---|---|---|
| id | UUID | PK |
| key | varchar(20) | PAR-01..PAR-18 |
| value | jsonb | versionado (RF-CFG-06) |
| version | int | incrementa por cambio |
| updated_by | UUID | FK lógica → Identity |
| updated_at | timestamp | |

## audit_db — AuditEvent (inmutable)

| Campo | Tipo | Notas |
|---|---|---|
| id | UUID | PK |
| event_id | UUID | correlaciona con evento Kafka |
| actor_id / actor_role | UUID / enum | |
| action | varchar(100) | ej. ADMIN_DELETED |
| resource_type / resource_id | varchar | |
| timestamp | timestamp | UTC |
| result | enum | SUCCESS \| FAILURE \| BLOCKED |
| reason | varchar(255) | overrides, excepciones |
| correlation_id | UUID | |
| metadata | jsonb | ip_hash, extra |

## reporting_db — read models

```text
CourseSnapshot          ← CourseCreated/Activated/Archived
RosterSnapshot          ← RosterUpdated
ConfigurationSnapshot   ← GlobalConfigurationChanged
```
Reconstruibles por **replay** de Kafka.

## Reglas transversales

- **Baja lógica:** `deleted_at`, `deleted_by`, `deletion_reason` en producción académica.
- **Encuestas:** cumplimiento (por alumno) y respuesta (anónima) **desacoplados**, sin vínculo posible.
- **Retención:** 5 años desde el cierre; vencimiento → decisión de ADMIN (extender/anonimizar); nunca purga automática.

> Fuente: `backoffice_backend_requerimientos_arquitectura.md` (§16).
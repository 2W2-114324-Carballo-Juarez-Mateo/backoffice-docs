# RULES — Stack y convenciones (Frontend)

1. **Caso A obligatorio:** apps **Angular SSR** independientes por dominio en **multirepos**. No se crea un Shell central que consuma librerías de todos (eso es Caso B).
2. **Nginx como única entrada pública**, con rutas por prefijo (`/`→alumno, `/profesor`, `/backoffice`, `/api/*`→BFF).
3. **BFF por experiencia** (BackOffice/Alumno/Profesor). El front **no** llama directo a microservicios.
4. **No tokens en JS:** la sesión viaja en cookie httpOnly; no uses localStorage para tokens.
5. **No store global cross-app** (NgRx es por app).
6. **UI desde `@tup/ui`**: no reimplementes componentes ni definas colores/tokens sueltos.
7. **Mantener `sdd/frontend/` sincronizado** con cualquier cambio del plan/implementación.
# SKILL — Configurar Nginx (prefijos y deep-links)

## Regla por app

Cada app tiene su `location` con fallback a **su propio** index:

```nginx
# BackOffice (SSR)
location /backoffice/ {
    proxy_pass http://backoffice-ssr:4000;
}

# Respaldar el caso estático / fallback profundo:
location /backoffice/ {
    try_files $uri $uri/ /backoffice/index.html;
}

# Alumno (raíz)
location / {
    proxy_pass http://alumno-ssr:4100;
}

# API → BFF/Gateway
location /api/ {
    proxy_pass http://bff-gateway:8080;
}
```

## Cache

```nginx
location /backoffice/ {
    # index.html: no cachear
    add_header Cache-Control "no-cache" always;
}
location /backoffice/assets/ {
    # assets con hash: inmutables
    expires 1y;
    add_header Cache-Control "public, immutable";
}
```

## Verificaciones

- Recargá una ruta profunda (`/backoffice/cursos/10`) → debe cargar el index de **BackOffice**, no 404 ni otra app.
- Si una app está caída → página de degradación sin romper el resto.
- Headers de seguridad: CSP, HSTS, `X-Content-Type-Options`.

> Reglas: `rules/RULES-deeplinks-cache.md`.